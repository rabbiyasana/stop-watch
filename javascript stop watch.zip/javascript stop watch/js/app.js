window.onload=function(){

    let miliseconds=00;
    let seconds=00;
    let minutes=00;
     let append_milisec=document.getElementById('mili-sec')
     let append_sec=document.getElementById('sec')
     let append_min=document.getElementById('min')


     let start =document.getElementById('start')
     let stop =document.getElementById('stop')
     let reset =document.getElementById('reset')
     let IntervalKey;


     start.onclick=function(){
        IntervalKey= setInterval(() => {
          miliseconds++;  
          if (miliseconds<9) {
            append_milisec.innerHTML='0'+miliseconds;
          }
          if (miliseconds>9) {
            append_milisec.innerHTML=miliseconds;
          }
          if (miliseconds>99) {
            seconds++;
            append_sec.innerHTML='0'+seconds;
            miliseconds=0;
            append_milisec.innerHTML='0'+0;
          }
          if (seconds>9) {
            append_sec.innerHTML=seconds;
            
          }
          if (seconds>60) {
            minutes++;
            append_min.innerHTML='0'+minutes;
            seconds=0;
          }
          if (minutes>9) {
            append_min.innerHTML=minutes;
            
          }
        }, 10);
     }

    //  stop function
     stop.onclick= function(){
        clearInterval(IntervalKey)
     }
     // rest function
    reset.onclick= function(){
    miliseconds=00;
    append_milisec.innerHTML='00';
    seconds=00;
    append_sec.innerHTML='00';
    minutes=00;
    append_min.innerHTML='00';
     }




    }